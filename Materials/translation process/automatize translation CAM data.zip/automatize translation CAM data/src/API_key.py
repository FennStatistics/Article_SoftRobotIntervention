"""
API-Key
"""

openai_api_key = "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"
